﻿namespace Ü283_Hotel
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //benjamin streitriegl
          
            int zimmerNummer = Meingabe("Bitte geben Sie die Zimmernummer ein:");
            int zuTauschendeZiffer = Meingabe("Bitte geben Sie die zu überprüfende Ziffer ein:");

            int Ergerbniss = EnthältNummerZ(ref zimmerNummer, zuTauschendeZiffer);
            if (Ergerbniss != -1)
            {
                Console.WriteLine("Die Zimmernummer" +zimmerNummer+" enthält die Ziffer "+Ergerbniss+ " und muss getauscht werden.");
            }
            else
            {
                Console.WriteLine("Die Zimmernummer "+zimmerNummer+" enthält nicht die Ziffer "+zuTauschendeZiffer+".");
            }
        }

        static int EnthältNummerZ(ref int zimmerNummer, int ziffer)
        {
            int originalNummer = zimmerNummer;
            int letzteZiffer;
            while (zimmerNummer > 0)
            {
                letzteZiffer = zimmerNummer % 10;
                if (letzteZiffer == ziffer)
                {
                    return letzteZiffer;
                }
                zimmerNummer /= 10;
            }
            return -1;
        }

        static int Meingabe(string message)
        {
            int Eingabe = 0;
            Console.WriteLine(message);
            string input = Console.ReadLine();
            int.TryParse(input, out Eingabe);
            return Eingabe;
        }
    }
}
